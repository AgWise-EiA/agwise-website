<p>
	 <?php _e('If you wish to limit posts that will feature in your News Sitemap to certain categories, select them here. If no categories are selected, posts of all categories will be included in your News Sitemap.','xml-sitemap-feed'); ?>
</p>
