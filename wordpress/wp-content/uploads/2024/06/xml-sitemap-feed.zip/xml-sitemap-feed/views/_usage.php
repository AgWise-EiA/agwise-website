<!-- Queries executed: <?php echo $num; if ( $mem ) { ?> | Peak memory usage: <?php echo $mem ? $mem : 'Not availabe.'; } ?> | Memory limit: <?php echo $limit; ?> -->
<!-- Query errors: <?php echo !empty($errors) ? $errors : 'None encountered.'; ?> -->
<!-- Queries: <?php echo !empty($saved) ? $saved : 'Set SAVEQUERIES to show saved database queries here.'; ?> -->
<!-- Average system load during the last minute: <?php $load = function_exists('sys_getloadavg') ? sys_getloadavg() : false; echo $load ? $load[0] : 'Not available.'; ?> -->
